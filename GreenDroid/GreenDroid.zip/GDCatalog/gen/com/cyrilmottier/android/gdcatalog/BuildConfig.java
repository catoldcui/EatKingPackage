/** Automatically generated file. DO NOT MODIFY */
package com.cyrilmottier.android.gdcatalog;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}